'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

require('./core-beb31360.js');
const utils = require('./utils-94b334b6.js');



exports.addIcons = utils.addIcons;
