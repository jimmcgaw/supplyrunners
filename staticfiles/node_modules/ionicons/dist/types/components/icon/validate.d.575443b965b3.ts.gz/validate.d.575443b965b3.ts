export declare const validateContent: (svgContent: string | null) => string;
export declare const isValid: (elm: HTMLElement) => boolean;
